document.addEventListener('click', function(e) {
    const target = e.target;
    if(target.matches('.dropdown-toggle')) {
        const menu = target.nextElementSibling;
        menu.classList.toggle('show');
    } else {
        document.querySelectorAll('.dropdown-menu').forEach(menu => menu.classList.remove('show'));
    }
});